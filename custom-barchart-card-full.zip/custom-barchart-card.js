// custom-barchart-card.js – bitte durch echten Code ersetzen
